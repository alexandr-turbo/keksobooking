// /**
//  * Функция, создающая метки и добавляющая изображение каждой метке
//  */
// (function () {
//   'use strict';
//   for (var n=0; n<HOUSE_COUNT; n++){
//     buttons[n] = document.querySelector('template').content.querySelector('button.map__pin').cloneNode(true);
//     buttons[n].setAttribute('style', 'left: ' + (advertsArray[n].location.x ) + 'px; top:' + (advertsArray[n].location.y) + 'px;');
//     buttons[n].querySelector('img').setAttribute('src', advertsArray[n].author.avatar);
//  }
// })();
